
$(function() {
    $('.svg').scrolla({
        // default
        mobile: false, // disable animation on mobiles
        once: false, // only once animation play on scroll
        animateCssVersion: 4 // used animate.css version (3 or 4)
    });
})